/******************************************************************************************
 *                                        
 *                         ��Դ֮nRF52832����ָ��
 *                                
 ******************************************************************************************
 ******************************************************************************************
 *                                        
 * SDK: nRF5_SDK_15.0.0_a53641a
 *                                                                               
 * ����: LED���
 *                         
 * ��Դ��������Ⱥ��326941601
 *                                        
 *****************************************************************************************/
#include <stdbool.h>
#include <stdint.h>
#include "nrf_delay.h"
#include "boards.h"

//IOӳ��
//LED1	P0.17
//LED2	P0.18
//LED3	P0.19
//LED4	P0.20

int main(void)
{
		//�������
		nrf_gpio_cfg_output(LED_1);
		nrf_gpio_cfg_output(LED_2);
		nrf_gpio_cfg_output(LED_3);
		nrf_gpio_cfg_output(LED_4);
		//�����
		nrf_gpio_pin_set(LED_1);
		//�����
		nrf_gpio_pin_clear(LED_1);
		//�����
		nrf_gpio_pin_write(LED_1,1);
		//�����
		nrf_gpio_pin_write(LED_1,0);
		while(1)
		{
//				/*����*/				
//				//����л�
//				nrf_gpio_pin_toggle(LED_1);
//				//��ʱ50ms
//				nrf_delay_ms(50);
			
				/*��ˮ��*/
				for (int i = 0; i < LEDS_NUMBER; i++)
				{
						bsp_board_led_invert(i);//�ڲ�����nrf_gpio_pin_toggle();
						nrf_delay_ms(50);
				}
		}
}
