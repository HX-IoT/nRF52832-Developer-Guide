/*****************************************************************************
 *                   SEGGER Microcontroller GmbH & Co. KG                    *
 *            Solutions for real time microcontroller applications           *
 *****************************************************************************
 *                                                                           *
 *               (c) 2017 SEGGER Microcontroller GmbH & Co. KG               *
 *                                                                           *
 *           Internet: www.segger.com   Support: support@segger.com          *
 *                                                                           *
 *****************************************************************************/

#ifndef __nRFxxx_h
#define __nRFxxx_h

#if defined(NRF51) || defined(NRF51) || defined(NRF51) || defined(NRF51) || defined(NRF51) || defined(NRF51) || defined(NRF51) || defined(NRF51) || defined(NRF52) || defined(NRF52832_XXAB) || defined(NRF52840_XXAA)

#include "nrf.h"

#endif

#endif
